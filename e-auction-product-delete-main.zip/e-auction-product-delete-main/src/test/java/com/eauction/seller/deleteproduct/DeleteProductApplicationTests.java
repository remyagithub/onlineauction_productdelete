package com.eauction.seller.deleteproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeleteProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
